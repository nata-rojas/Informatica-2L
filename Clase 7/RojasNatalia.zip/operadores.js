let a = parseFloat(prompt("Ingrese un número"));
let b = parseFloat(prompt("Ingrese un número"));

console.log (`La suma es: ${a + b}`);
console.log (`La resta es: ${a - b}`);
console.log (`La multiplicación es: ${a * b}`);
console.log (`La división es: ${a / b}`);
console.log (`El módulo es: ${a % b}`);

//variables lógicas
let p = true;
let q = false;

console.log(`p: ${p}, q ${q}`);
console.log(`Or logico: ${p || q}`);
console.log(`And logico: ${p && q}`);
console.log(`No p: ${!p}`);
console.log(`No q: ${!q}`);