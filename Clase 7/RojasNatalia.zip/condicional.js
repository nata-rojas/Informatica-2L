let a = parseFloat(prompt("Ingrese un número"));
let b = parseFloat(prompt("Ingrese un número"));

if ( b == 0) {
    alert ("No es posible calcular la división ni el módulo.");
}
